<?php $__env->startSection('title_page'); ?>
<title>Chọn lựa bài thi</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class= "container-fluid">
<div class="card mb-3">
    <div class="card-header" style="font-size:17px;">
        <i class="fa fa-area-chart"></i>
        <b>Chọn lựa bài thi</b>
    </div>
    <br>
    <div class="card-body">
        <form class="form-horizontal" action="DoTest">
            <div class="row">
                <div class="col-lg-6 row">
                    <div class="control-label col-sm-4">
                        <h7 style="font-size:16px; margin-top:5px;"><b>Lớp</b></h7>
                    </div>
                    <div class="col-sm-5">
                        <select name="updateQuestionSubject" id="updateQuestionSubject" class="form-control">
                            <option value="toan">Toán</option>
                            <option value="van">Văn</option>
                            <option value="anhvan">Anh Văn</option>
                            <option value="dia">Đia lý</option>
                            <option value="su">Lịch sử</option>
                        </select>
                    </div>
                </div>  
                <div class="col-lg-6 row">
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-lg-6 row">
                    <div class="control-label col-sm-4">
                        <h7 style=" font-size:16px; margin-top:5px;"><b>Môn học</b></h7>
                    </div>
                    <div class="col-sm-5">
                    <select name="updateQuestionSubject" id="updateQuestionSubject" class="form-control">
                        <option value="toan">Toán</option>
                        <option value="van">Văn</option>
                        <option value="anhvan">Anh Văn</option>
                        <option value="dia">Đia lý</option>
                        <option value="su">Lịch sử</option>
                    </select>
                    </div>
                </div>  
                <div class="col-lg-6 row">
                    <div class="control-label col-sm-3">
                    <h7 style="font-size:16px; margin-top:5px;"><b>Mức độ</b></h7>
                    </div>
                    <div class="col-sm-5">
                        <select name="updateQuestionLevel" id="updateQuestionLevel" class="form-control">
                        <option value="de">Dễ</option>
                        <option value="trungbinh">Trung bình</option>
                        <option value="kho">Khó</option>
                        </select>
                    </div>
                </div>
            </div>
        <br><br>
        <center><input type="submit" class="btn btn-primary " style="text-align:center;" id="startTest" value="Làm bài"></center>
        </form>
    </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.student.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>