<?php $__env->startSection('title_page'); ?>
<title>Danh sách đề thi</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(isset($error)): ?> 
<script language='javascript'>
  alert(" <?php echo e($error); ?>");
</script>
<?php endif; ?>

      <div class="container-fluid">
        <div class="">
          <div class="card-header" style="background-color:white;">
            <i class="fa fa-table"></i>
            <b style="font-size:20px;"> Danh sách đề thi</b>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>STT</th>
                    <th>Tên bài thi</th>
                    <th>Lớp</th>
                    <th>Môn</th>
                    <th>Mức độ</th>
                    <th>Tổng số câu</th>
                    <th>Thời gian làm</th>
                    <th>Hành động</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>
                    <th>STT</th>
                    <th>Tên bài thi</th>
                    <th>Lớp</th>
                    <th>Môn</th>
                    <th>Mức độ</th>
                    <th>Tổng số câu</th>
                    <th>Thời gian làm</th>
                    <th>Hành động</th>
                  </tr>
                </tfoot>
                <tbody>
                  

                  <?php for($i = 0; $i < count($data); $i++): ?>
                  <tr>
                    <td><?php echo e($i+1); ?></td>
                    
                    <td><?php echo e($data[$i]['quizz_name']); ?></td>
                    <td><?php echo e($data[$i]['class_name']); ?></td>
                    <td><?php echo e($data[$i]['topic_name']); ?></td>
                    <td><?php echo e($data[$i]['level_name']); ?></td>
                    <td><?php echo e($data[$i]['total']); ?></td>
                    <td><?php echo e($data[$i]['duration']); ?></td>
                    <!-- <td><?php echo e($data[$i]['updated_at']); ?></td> -->
                    <td>
                        <!-- <input type="hidden" id="quizzId" name="quizzId" value="<?php echo e($data[$i]['quizz_id']); ?>"> -->
                        <a href="<?php echo e(url('/Students/DoTest', $data[$i]['quizz_id'])); ?>" class="btn btn-success">Làm bài</a>
                        <!-- <a href="/Students/DoTest/<?php echo e($data[$i]['quizz_id']); ?>" class="btn btn-success">Làm bài</a> -->
                    </td>
                  </tr>
                  <?php endfor; ?>
                 
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>


    <!-- Logout Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Select "Logout" below if you are ready to end your current session.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="./Admin/Login">Logout</a>
            </div>
        </div>
      </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $( ".btnUpdate" ).click(function() {
        $.showLoading({name: 'circle-fade',allowHide: false});  
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.student.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>