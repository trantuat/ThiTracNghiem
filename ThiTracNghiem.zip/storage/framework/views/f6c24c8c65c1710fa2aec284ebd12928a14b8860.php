<ul class="navbar-nav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="profile">
            <a class="nav-link" href="/Teacher/Profile">
                <i class="fa fa-user-circle"></i>
                <span class="nav-link-text">
                Thông tin cá nhân</span>
            </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="question">
            <a class="nav-link" href="/Teacher/Question">
                <i class="fa fa-question-circle"></i>
                <span class="nav-link-text">
                Quản lý câu hỏi</span>
            </a>
        </li>
       
</ul>