<?php $__env->startSection('title_page'); ?>
<title>Lịch sử bài thi</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(isset($error)): ?> 
<script language='javascript'>
  alert(" <?php echo e($error); ?>");
</script>
<?php endif; ?>

      <div class="container-fluid">
        <div class="">
          <div class="card-header" style="background-color:white;">
            <i class="fa fa-table"></i>
            <b style="font-size:20px;"> Danh sách bài đã làm</b>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>STT</th>
                    <th>Tên bài thi</th>
                    <th>Tổng số câu</th>
                    <th>Thời gian làm</th>
                    <th>Ngày làm</th>
                    <th>Hành động</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>
                    <th>STT</th>
                    <th>Tên bài thi</th>
                    <th>Tổng số câu</th>
                    <th>Thời gian làm</th>
                    <th>Ngày làm</th>
                    <th>Hành động</th>
                  </tr>
                </tfoot>
                <tbody>
                  
                 

                  <?php for($i = 0; $i < count($data); $i++): ?>
                  <tr>
                    <td><?php echo e($i+1); ?></td>
                    <td><?php echo e($data[$i]['quizz_name']); ?></td>
                    <td><?php echo e($data[$i]['total']); ?></td>
                    <td><?php echo e($data[$i]['duration']); ?></td>
                    <td>NULL</td>
                    <td>
                      <!-- <button style="color: red; border: 0; background:none;" data-toggle='modal' title='see result' data-target='#seeResultOfStudent'><b><i class="fa fa-list"></i></b></button> -->
                      
                      <a href="<?php echo e(url('/Students/TestTime', $data[$i]['id'])); ?>" ><button style="color: red; border: 0;background:none;" ><b><i class="fa fa-list"></i></b></button></a>
                      <!-- <button style="color: red; border: 0; background:none;" data-toggle='modal' title='Update info' data-target='#updateStudent'><b><i class="fa fa-pencil-square-o"></i></b></button> -->
                      <button style="color: red; border: 0; background:none;" data-toggle='confirmation' title='Delete student' ><b><i class="fa fa-trash"></i></b></button>
                    </td>
                  </tr>
                  <?php endfor; ?>
                 
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>


    <!-- Logout Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Select "Logout" below if you are ready to end your current session.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="./Admin/Login">Logout</a>
            </div>
        </div>
      </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $( ".btnUpdate" ).click(function() {
        $.showLoading({name: 'circle-fade',allowHide: false});  
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.student.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>