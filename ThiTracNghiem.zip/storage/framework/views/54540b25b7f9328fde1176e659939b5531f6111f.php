<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(URL::asset("vendor/bootstrap/css/bootstrap.min.css")); ?>" rel="stylesheet">
    <!-- Custom fonts for this template -->
    <link href="<?php echo e(URL::asset("vendor/font-awesome/css/font-awesome.min.css")); ?>" rel="stylesheet" type="text/css">

    <!-- Plugin CSS -->
    <link href="<?php echo e(URL::asset("vendor/datatables/dataTables.bootstrap4.css")); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(URL::asset("css/sb-admin.css")); ?>" rel="stylesheet">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php echo $__env->yieldContent('title_page'); ?>

</head>
<?php
    $role = 1;
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
        <?php if($role == 1): ?> {
            <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
            <?php echo $__env->yieldContent('content'); ?>;
            <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
        } <?php elseif($role == 2): ?> {
            <?php echo $__env->yieldContent('content'); ?>
        } <?php else: ?> {
            <?php echo $__env->yieldContent('content'); ?>
        } <?php endif; ?>
        <?php echo $__env->yieldContent('script'); ?>;
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

      <!-- Bootstrap core JavaScript -->
    <script src="<?php echo e(URL::asset("vendor/jquery/jquery.min.js")); ?>"></script>
    <script src="<?php echo e(URL::asset("vendor/popper/popper.min.js")); ?>"></script>
    <script src="<?php echo e(URL::asset("vendor/bootstrap/js/bootstrap.min.js")); ?>"></script>

    <!-- Plugin JavaScript -->
    <script src="<?php echo e(URL::asset("vendor/jquery-easing/jquery.easing.min.js")); ?>"></script>
    <script src="<?php echo e(URL::asset("vendor/chart.js/Chart.min.js")); ?>"></script>
    <script src="<?php echo e(URL::asset("vendor/datatables/jquery.dataTables.js")); ?>"></script>
    <script src="<?php echo e(URL::asset("vendor/datatables/dataTables.bootstrap4.js")); ?>"></script>

    <!-- Custom scripts for this template -->
    <script src="js/sb-admin.min.js"></script>

</body>
</html>
