<?php $__env->startSection('title_page'); ?>
<title>Danh sách câu hỏi</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class= "container-fluid">
  <div class="row">
      <div class="col-lg-5" >
        <div class="col-lg-5" style="margin: 0 auto; width: 100%;display: block;" >
            <img class="rounded-circle img-fluid d-block mx-auto" src="http://placehold.it/200x200" alt="">
            <br>
            <center><h6>John Smith</h6></center>
        </div>
        <br>
        
        <div class="col-lg-8" style="margin: 0 auto; width: 100%;display: block;">
          <!-- <input type="text" class="form-control" placeholder="Account" readonly>
          <span class="input-group-btn">
            <button class="btn btn-secondary" type="button" id="account"><i class="fa fa-user"></i></button>
          </span>
        </div>
        <br>
        <div class="input-group col-lg-8 col-md-6">
          <input type="text" class="form-control" placeholder="Password" readonly>
          <span class="input-group-btn">
            <button class="btn btn-secondary" type="button" id="pass"><i class="fa fa-snowflake-o"></i></button>
          </span> -->
          <div class="list-group" >
            <div class="input-group" >
              <button type="button" class="list-group-item list-group-item-action active " id="showAccount" onClick="showProfile()">
                <i class="fa fa-user"></i> Cập nhật tài khoản
                </button>
            </div>
            <br>
            <div class="input-group">
              <button type="button" class="list-group-item list-group-item-action " id="showPass" onClick="changePassword()">
                <i class="fa fa-snowflake-o"></i> Cập nhật mật khẩu
                </button>
            </div>
            <br>
          </div>
        </div>
      </div>
      <div class="col-lg-6" style="margin-top:20px;" >
          <div id="showProfile">
          <h4 style="color:red;"><i class="fa fa-user"></i> Thông tin tài khoản  </h4>
          <br>
          <form action="" class="form-horizontal" >
            <label><strong>Username<strong></label>
            <div class="input-group">
              <input type="text" class="form-control" placeholder="lehainghi" id="userName" required>
            </div>
            <br>
            <label><strong>Tên đầy đủ<strong></label>
            <div class="input-group">
              <input type="text" class="form-control" placeholder="Lê Hải Nghi" id="fullName" required>
            </div>
            <br>
            <label><strong>Ngày sinh<strong></label>
            <div class="input-group">
              <input type="datetime-local" class="form-control" placeholder="29/08/1995" id="dayOfBirth" required>
            </div>
            <br>
            <label><strong>Địa chỉ<strong></label>
            <div class="input-group">
              <input type="text" class="form-control" placeholder="Danang" id="address" required>
            </div>
            <br>
            <label><strong>Email<strong></label>
            <div class="input-group">
              <input type="email" class="form-control" placeholder="abc@gmail.com" id="email" required>
            </div>
            <br>
            <label><strong>Số điện thoại<strong></label>
            <div class="input-group">
              <input type="number" maxlength="11" minlength="10" class="form-control" placeholder="11111111" id="phoneNumber" required>
            </div>
            <br>
            <div class="col-sm-5">
              <button class="btn btn-success btn-block" id="updateProfile">Cập nhật</button>
            </div>
          </form>
        </div>

      <!-- Form pass -->
        <div id="change">
          <h4 style="color:red;"><i class="fa fa-snowflake-o"></i> Mật khẩu </h4>
          <br>
          <form action="" class="form-horizontal" >
            <label><strong><strong>Mật khẩu cũ</label>
            <div class="input-group">
              <input type="password" class="form-control" id="oldPass" required>
            </div>
            <br>
            <label><strong><strong>Mật khẩu mới</label>
            <div class="input-group">
              <input type="password" class="form-control" id="newPass" required>
            </div>
            <br>
            <label><strong>Xác nhận mật khẩu mới<strong></label>
            <div class="input-group">
              <input type="password" class="form-control"  id="confirmPass" required>
            </div>
            <br>
            <div class="col-sm-5">
              <button class="btn btn-success btn-block" id="updatePass">Lưu mật khẩu</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<br>
<?php $__env->stopSection(); ?>
<script type="text/javascript">

  window.onload = function() {

    document.getElementById("showProfile").style.display = "block";
    document.getElementById("change").style.display = "none";

  };

  function showProfile() {
      document.getElementById("change").style.display = "none";
      document.getElementById("showProfile").style.display = "block";
      document.getElementById("showPass").classList.remove("active");
      document.getElementById("showAccount").className += " active"; 
    } 
    
function changePassword(){
      document.getElementById("showProfile").style.display = "none";
      document.getElementById("change").style.display = "block";
      document.getElementById("showPass").className += " active"; 
      document.getElementById("showAccount").classList.remove("active");
}

</script>

<?php echo $__env->make('layouts.student.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>