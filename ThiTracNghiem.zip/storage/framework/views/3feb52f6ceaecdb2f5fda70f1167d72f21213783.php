<?php $__env->startSection('title_page'); ?>
<title>Student page</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <p>Hello</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.student.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>