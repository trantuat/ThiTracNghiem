<?php $__env->startSection('title_page'); ?>
<title>Profile</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <h3 style = "color: red;">Bun banh beo</h3>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>