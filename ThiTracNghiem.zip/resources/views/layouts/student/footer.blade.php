<!-- <footer class="py-5 bg-dark">
<div class="container">
  <p class="m-0 text-center text-white">Copyright &copy; Your Website 2017</p>
</div>
</footer> -->

<footer class="py-5 bg-dark ">
<div class="container-fluid">
    <div class="m-1 text-center">
    <small>Copyright &copy; Your Website 2017</small>
    </div>
</div>
</footer>