<ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
    <li class="nav-item" data-toggle="tooltip" data-placement="right" title="profile">
        <a class="nav-link" href="/Teachers/Profile">
            <i class="fa fa-user-circle"></i>
            <span class="nav-link-text">
            Thông tin cá nhân</span>
        </a>
    </li>
    <li class="nav-item" data-toggle="tooltip" data-placement="right" title="question">
        <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#showListOfQuestion" data-parent="#exampleAccordion">
            <i class="fa fa-question-circle"></i>
            <span class="nav-link-text">
            Quản lý câu hỏi</span>
        </a>
        <ul class="sidenav-second-level collapse" id="showListOfQuestion">
            <li>
                <a href="/Teachers/Question">Danh sách câu hỏi</a>
            </li>
            <li>
                <a href="/Teachers/UncheckedQuestion">Danh sách chờ xét duyệt</a>
            </li>
        </ul>
    </li>
    
       
</ul>